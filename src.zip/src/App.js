import './App.css';
import { Signup } from './Sign';


function App() {
  return (
   <>
      <Signup/>
      {/* <Dhaval/> */}
   </>
  );
}

export default App;
